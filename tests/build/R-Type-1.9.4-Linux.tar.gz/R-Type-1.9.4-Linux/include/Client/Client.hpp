/*
** EPITECH PROJECT, 2023
** B-CPP-500-LYN-5-2-rtype-erwann.laplante
** File description:
** main
*/

#ifndef MAIN_HPP_
#define MAIN_HPP_

#include <Error/Error.hpp>
#include <Graph/Game.hpp>
#include <Graph/Window.hpp>
#include <iostream>

#endif /* !MAIN_HPP_ */
